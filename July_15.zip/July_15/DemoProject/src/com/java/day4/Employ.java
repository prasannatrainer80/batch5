package com.java.day4;

public class Employ {
	
	int empno;
	String name;
	double basic;
	
}
