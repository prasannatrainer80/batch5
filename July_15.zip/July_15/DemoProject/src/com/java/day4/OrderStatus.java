package com.java.day4;

public enum OrderStatus {
	PENDING, ACCEPTED, REJECTED
}
