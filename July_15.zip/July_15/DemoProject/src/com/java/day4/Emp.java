package com.java.day4;

public class Emp {

	int empno;
	String name;
	double basic;
	
	@Override
	public String toString() {
		return "Emp [empno=" + empno + ", name=" + name + ", basic=" + basic + "]";
	}

	
}
