package com.java.day4;

public class StrEx {

	public static void main(String[] args) {
		String s1="Hyma", s2="Srinivas", s3="Teja", s4="Hyma";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
	}
}
