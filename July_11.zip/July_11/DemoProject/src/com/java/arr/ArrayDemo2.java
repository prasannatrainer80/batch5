package com.java.arr;

public class ArrayDemo2 {

	public static void main(String[] args) {
		String[] names = new String[] {
			"Nagaraju","Hemanth","Pavan",
			"Rajitha","Srinu"
		};
		
		for (String s : names) {
			System.out.println(s);
		}
	}
}
