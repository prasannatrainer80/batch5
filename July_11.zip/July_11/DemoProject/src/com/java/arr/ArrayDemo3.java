package com.java.arr;

public class ArrayDemo3 {

	public static void main(String[] args) {
		int[] a = {1,2,3};
		int[] b = {4,5,6};
		
	}
}
