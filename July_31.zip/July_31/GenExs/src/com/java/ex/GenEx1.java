package com.java.ex;

import java.util.ArrayList;
import java.util.List;

public class GenEx1 {

	public static void main(String[] args) {
		List<Object> lists = new ArrayList<Object>();
		lists.add(new Integer(3));
		lists.add(new String("Hello"));
		lists.add(new Double(423));
	}
}
