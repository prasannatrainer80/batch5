package com.java.day1;

public class Demo {
	public void sayHello() {
		System.out.println("Welcome to Java Programming....");
	}
	
	private void trainer() {
		System.out.println("Trainer is Prasanna P...");
	}
	
	void company() {
		System.out.println("Company is Sonix...");
	}
}
