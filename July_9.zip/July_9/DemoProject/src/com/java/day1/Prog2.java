package com.java.day1;

public class Prog2 {

	public static void main(String[] args) {
		int x=12;
//		System.out.println(x++);
		System.out.println(++x);
	}
}
