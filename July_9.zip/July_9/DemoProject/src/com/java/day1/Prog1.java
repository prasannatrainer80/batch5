package com.java.day1;

public class Prog1 {

	public static void main(String[] args) {
		int x=12;
		String name="Surya";
		double basic=88423.55;
		System.out.println("X value " +x+" Name " +name+ " Basic " +basic);
	}
}
