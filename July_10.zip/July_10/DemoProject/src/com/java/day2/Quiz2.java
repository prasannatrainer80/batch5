package com.java.day2;

public class Quiz2 {

	public static void main(String[] args) {
		int ch='A';
		System.out.println(ch);
	}
}
