package com.java.day2;

public class Quiz1 {

	public static void main(String[] args) {
		int i=8;
		while(i < 10) {
			System.out.println("Hi");
			i--;
		}
	}
}
