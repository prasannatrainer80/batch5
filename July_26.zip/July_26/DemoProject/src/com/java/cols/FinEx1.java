package com.java.cols;

public class FinEx1 {

	public static void main(String[] args) {
		final String company = "Sonix";
//		company = "Sonix Ltd";
	}
}
