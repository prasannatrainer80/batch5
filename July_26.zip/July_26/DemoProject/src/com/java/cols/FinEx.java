package com.java.cols;

final class Test {
	public void show() {
		System.out.println("From Show Method...");
	}
}

class Hello extends Test {
	
}
public class FinEx {

}
