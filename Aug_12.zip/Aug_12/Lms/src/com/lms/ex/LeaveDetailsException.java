package com.lms.ex;

public class LeaveDetailsException extends Exception {

	public LeaveDetailsException(String error) {
		super(error);
	}
}
