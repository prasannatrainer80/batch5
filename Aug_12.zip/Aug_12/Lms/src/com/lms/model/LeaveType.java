package com.lms.model;

public enum LeaveType {
		EL,PL,ML
}
