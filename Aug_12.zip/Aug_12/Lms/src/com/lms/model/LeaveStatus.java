package com.lms.model;

public enum LeaveStatus {
	ACCEPTED,REJECTED,PENDING
}
