package com.java.st;

public class StudentMain {
	public static void main(String[] args) {
		Student s1 = new Student(1, "Padma", "Hyd", 9.2);
		Student s2 = new Student(2, "Ammar", "Chennai", 9.1);
		Student s3 = new Student(3, "Nagaraju", "Chennai", 9.5);
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
	}
}
