package com.java.st;

public class ConEmp {

	public static void main(String[] args) {
		Emp e1 = new Emp(1, "Pavan", 99423.44);
		Emp e2 = new Emp(2, "Ammar",99224.44);
		System.out.println(e1);
		System.out.println(e2);
	}
}
