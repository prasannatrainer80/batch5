package com.java.p2;

public class Hello {

}
